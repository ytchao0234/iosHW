//
//  KeepView.swift
//  NovelReader
//
//  Created by User08 on 2021/12/25.
//

import SwiftUI
import MapboxSpeech
import AVKit

struct KeepView: View {
    @State var data: Data? = nil

    var body: some View {
        let documentDirectory = FileManager.default.urls(for:.documentDirectory, in: .userDomainMask).first!
        let url = documentDirectory.appendingPathComponent("testMP3")

        return VStack {
            Button(action: {
                do {
                    let player = try AVAudioPlayer(data: self.data!, fileTypeHint: AVFileType.mp3.rawValue)
                    print(player)
                    player.play()
                    print("play")
                }
                catch {
                    print("ERROR:play:\(error)")
                }
            }, label: {
                Text("play")
            })
        }
            .onAppear {
                let speechSynthesizer = SpeechSynthesizer(accessToken: "pk.eyJ1IjoieXRjaGFvIiwiYSI6ImNreG15c3d1cjBpNmYydmp2MHNqcnpzMjIifQ.FUCYX4JeNW5qz9F9_MGHzg")
                let options = SpeechOptions(text: "hello, my name is Bobby.")
                options.outputFormat = .mp3
                options.speechGender = .female
                options.locale = Locale(identifier: "en_US")

                speechSynthesizer.audioData(with: options) { (data, error) in
                    guard error == nil else {
                        print("Error:speechSynthesizer: \(String(describing: error))")
                        return
                    }
                    
                    print(data ?? "no data")
                    self.data = data
                    try! data!.write(to: url)
                }
            }
    }
}

struct KeepView_Previews: PreviewProvider {
    static var previews: some View {
        KeepView()
    }
}
