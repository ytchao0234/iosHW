//
//  RandomGameApp.swift
//  RandomGame
//
//  Created by FanRende on 2021/10/27.
//

import SwiftUI

@main
struct RandomGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
